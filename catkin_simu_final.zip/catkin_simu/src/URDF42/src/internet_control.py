import pyrebase
import time
# from PyQt5 import QtCore, QtGui, QtWidgets
import rospy
from std_msgs.msg import Float64
from geometry_msgs.msg import Twist, Pose, Point, Quaternion
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal


firebaseConfig = {
    "apiKey": "AIzaSyC60btinIfRYE45Pkko_AZULWYXYdpWbSk",
    "authDomain": "ros-firebase-robot-a5b5b.firebaseapp.com",
    "databaseURL": "https://ros-firebase-robot-a5b5b-default-rtdb.firebaseio.com",
    "projectId": "ros-firebase-robot-a5b5b",
    "storageBucket": "ros-firebase-robot-a5b5b.appspot.com",
    "messagingSenderId": "386372750947",
    "appId": "1:386372750947:web:6b4e4fd35da05877563256"
  }

firebase = pyrebase.initialize_app(firebaseConfig)

db = firebase.database()

count = 0


def move_to_goal(x_goal, y_goal,z_orientation, w_orientation=1.0):
    # Khởi tạo node ROS
    rospy.init_node('send_goal_node', anonymous=True)

    # Kết nối tới action server 'move_base'
    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
    client.wait_for_server()

    # Tạo goal mới
    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "map"  # frame_id thường là "map" hoặc "odom" tùy vào hệ thống bạn đang sử dụng
    goal.target_pose.header.stamp = rospy.Time.now()

    # Đặt vị trí cho goal
    goal.target_pose.pose = Pose(Point(x_goal, y_goal, 0.0), Quaternion(0.0, 0.0, z_orientation, w_orientation))

    # Gửi goal đến move_base
    rospy.loginfo("Sending goal location ...")
    client.send_goal(goal)

    # Chờ kết quả
    client.wait_for_result()

    # Kiểm tra kết quả
    if client.get_state() == actionlib.GoalStatus.SUCCEEDED:
        rospy.loginfo("You have reached the destination")
    else:
        rospy.loginfo("The robot failed to reach the destination")


while True:
    direction = db.child("test").child("command").get().val()

    if direction == "T1":
        x_goal = 3.4707326889038086
        y_goal = 2.5648136138916016
        z_orientation = -0.9996454583672367
        w_orientation = 0.026626257073746214
        move_to_goal(x_goal, y_goal, z_orientation, w_orientation)


    elif direction == "T2":
        x_goal = 3.8285419940948486
        y_goal = 8.299715995788574
        z_orientation = -0.9999900321709365
        w_orientation = 0.004464925393470992
        move_to_goal(x_goal, y_goal, z_orientation, w_orientation)

    elif direction == "T3":
        x_goal = 7.264925956726074
        y_goal = 2.4457054138183594
        z_orientation = -0.9999881792138406
        w_orientation = 0.004862245632194718
        move_to_goal(x_goal, y_goal, z_orientation, w_orientation)



    elif direction == "T4":
        x_goal = 7.2220869064331055
        y_goal = 8.31216812133789
        z_orientation = -0.9999735125733213
        w_orientation = 0.007278334409291973
        move_to_goal(x_goal, y_goal, z_orientation, w_orientation)



    elif direction == "T5":
        x_goal = 10.547332763671875
        y_goal = 2.3155388832092285
        z_orientation = 0.999931392613748
        w_orientation = 0.011713670028248274
        move_to_goal(x_goal, y_goal, z_orientation, w_orientation)



    elif direction == "T6":
        x_goal = 10.499119758605957
        y_goal = 8.060577392578125
        z_orientation = 0.9993701821110914
        w_orientation = 0.03548575921752356
        move_to_goal(x_goal, y_goal, z_orientation, w_orientation)

    elif direction == "HOME":
        x_goal = 0
        y_goal = 0
        z_orientation = 0
        w_orientation = 1
        move_to_goal(x_goal, y_goal, z_orientation, w_orientation)