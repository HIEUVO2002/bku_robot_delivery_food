from PyQt5 import QtWidgets, uic, QtGui
from PyQt5.QtWidgets import QMainWindow, QApplication, QLCDNumber, QProgressBar, QLabel, QComboBox, QPushButton, QSlider
from PyQt5.QtCore import QTime, QTimer
import sys
import pyrebase
import time
from PyQt5.QtWidgets import (QApplication, QWidget)
from PyQt5.Qt import Qt

firebaseConfig = {
    "apiKey": "AIzaSyC60btinIfRYE45Pkko_AZULWYXYdpWbSk",
    "authDomain": "ros-firebase-robot-a5b5b.firebaseapp.com",
    "databaseURL": "https://ros-firebase-robot-a5b5b-default-rtdb.firebaseio.com",
    "projectId": "ros-firebase-robot-a5b5b",
    "storageBucket": "ros-firebase-robot-a5b5b.appspot.com",
    "messagingSenderId": "386372750947",
    "appId": "1:386372750947:web:6b4e4fd35da05877563256"
  }

firebase = pyrebase.initialize_app(firebaseConfig)

db = firebase.database()



class Ui(QtWidgets.QMainWindow):
    def __init__(self):
        super(Ui, self).__init__()
        uic.loadUi('remote_gui_ros.ui', self)

        # self.setWindowIcon(QtGui.QIcon('images/icon_1.png'))
        # set the title
        self.setWindowTitle("Icon")

        self.arm = self.findChild(QSlider, "arm_slider")
        self.arm.valueChanged.connect(self.change_angle)

        self.front_button = self.findChild(QPushButton, "front_button")
        self.front_button.clicked.connect(self.front_button_clicked)

        self.back_button = self.findChild(QPushButton, "back_button")
        self.back_button.clicked.connect(self.back_button_clicked)

        self.stop_button = self.findChild(QPushButton, "stop_button")
        self.stop_button.clicked.connect(self.stop_button_clicked)

        self.left_button = self.findChild(QPushButton, "left_button")
        self.left_button.clicked.connect(self.left_button_clicked)

        self.right_button = self.findChild(QPushButton, "right_button")
        self.right_button.clicked.connect(self.right_button_clicked)

        self.lturn_button = self.findChild(QPushButton, "left_turn_button")
        self.lturn_button.clicked.connect(self.lturn_button_clicked)

        self.rturn_button = self.findChild(QPushButton, "right_turn_button")
        self.rturn_button.clicked.connect(self.rturn_button_clicked)

        # For adding new button for ZIG ZAG movement
        self.back_button = self.findChild(QPushButton, "zig_zag_button")
        self.back_button.clicked.connect(self.zig_zag_button_clicked)

        self.show()

    def clickme(self):
        global light_status
        light_status = not light_status
        if(light_status == True):
            db.child("test").update({"light": 1})
            print("LIGHT ON")
        else:
            db.child("test").update({"light": 0})
            print("LIGHT OFF")


    def lturn_button_clicked(self):
        db.child("test").update({"command": "T1"})
        db.child("test").update({"status": "Moving to Table 1"})
        print("GO TO TABLE 1")

    def front_button_clicked(self):
        db.child("test").update({"command": "T2"})
        db.child("test").update({"status": "Moving to Table 2"})
        print("GO TO TABLE 2")


    def rturn_button_clicked(self):
        db.child("test").update({"command": "T3"})
        db.child("test").update({"status": "Moving to Table 3"})
        print("GO TO TABLE 3")


    def left_button_clicked(self):
        db.child("test").update({"command": "T4"})
        db.child("test").update({"status": "Moving to Table 4"})
        print("GO TO TABLE 4")


    def stop_button_clicked(self):
        db.child("test").update({"command": "T5"})
        db.child("test").update({"status": "Moving to Table 5"})
        print("GO TO TABLE 5")


    def right_button_clicked(self):
        db.child("test").update({"command": "T6"})
        db.child("test").update({"status": "Moving to Table 6"})
        print("GO TO TABLE 6")

    def back_button_clicked(self):
        db.child("test").update({"command": "HOME"})
        db.child("test").update({"status": "Home"})
        print("HOME")

    

    
    
    # Function for the new button for ZIG ZAG movement
    def zig_zag_button_clicked(self):
        db.child("test").update({"command": "ZIGZAG"})
        print("GO ZIGZAG")

    def change_angle(self, value):
        # Change font size of label. Size value could
        # be anything consistent with the dimension of label.
        db.child("test").update({"arm": value})
        print(value)


app = QtWidgets.QApplication(sys.argv)
window = Ui()
app.exec_()
