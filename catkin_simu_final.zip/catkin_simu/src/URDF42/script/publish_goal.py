#!/usr/bin/env python3

import rospy
import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from geometry_msgs.msg import Pose, Point, Quaternion

def move_to_goal(x_goal, y_goal,z_orientation, w_orientation=1.0):
    # Khởi tạo node ROS
    rospy.init_node('send_goal_node', anonymous=True)

    # Kết nối tới action server 'move_base'
    client = actionlib.SimpleActionClient('move_base', MoveBaseAction)
    client.wait_for_server()

    # Tạo goal mới
    goal = MoveBaseGoal()
    goal.target_pose.header.frame_id = "map"  # frame_id thường là "map" hoặc "odom" tùy vào hệ thống bạn đang sử dụng
    goal.target_pose.header.stamp = rospy.Time.now()

    # Đặt vị trí cho goal
    goal.target_pose.pose = Pose(Point(x_goal, y_goal, 0.0), Quaternion(0.0, 0.0, z_orientation, w_orientation))

    # Gửi goal đến move_base
    rospy.loginfo("Sending goal location ...")
    client.send_goal(goal)

    # Chờ kết quả
    client.wait_for_result()

    # Kiểm tra kết quả
    if client.get_state() == actionlib.GoalStatus.SUCCEEDED:
        rospy.loginfo("You have reached the destination")
    else:
        rospy.loginfo("The robot failed to reach the destination")

if __name__ == '__main__':
    try:
        # Đặt tọa độ của goal
        x_goal = 3
        y_goal = 0
        z_orientation = 0
        w_orientation = 1  # Hướng của robot (1.0 là không xoay, bạn có thể thay đổi giá trị này)

        move_to_goal(x_goal, y_goal, z_orientation, w_orientation)
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation test finished.")
