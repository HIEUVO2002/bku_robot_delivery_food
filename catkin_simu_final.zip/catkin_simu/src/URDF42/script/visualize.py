# import rospy
# from geometry_msgs.msg import PoseWithCovarianceStamped
# from nav_msgs.msg import Path
# import matplotlib.pyplot as plt
# from threading import Thread
# from queue import Queue

# # Queues to store data from ROS topics
# pose_data = Queue()
# path_data = Queue()

# def amcl_pose_callback(msg):
#     # Extract position from amcl_pose message and store it in the queue
#     x = msg.pose.pose.position.x
#     y = msg.pose.pose.position.y
#     pose_data.put((x, y))

# def global_plan_callback(msg):
#     # Extract the global plan path and store it in the queue
#     path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]
#     path_data.put(path)

# def plot_thread():
#     # Initialize the plot
#     plt.ion()
#     fig, ax = plt.subplots()
#     pose_x_data, pose_y_data = [], []
#     path_x_data, path_y_data = [], []

#     while not rospy.is_shutdown():
#         # Update pose data
#         while not pose_data.empty():
#             x, y = pose_data.get()
#             pose_x_data.append(x)
#             pose_y_data.append(y)

#         # Update path data
#         if not path_data.empty():
#             path = path_data.get()
#             path_x_data, path_y_data = zip(*path)

#         # Plotting
#         ax.clear()
#         ax.plot(pose_x_data, pose_y_data, label="Robot_position", color="blue")
#         if path_x_data and path_y_data:
#             ax.plot(path_x_data, path_y_data, label="Global Plan", color="red")
#         ax.set_xlabel('X Position')
#         ax.set_ylabel('Y Position')
#         ax.legend()
#         plt.draw()
#         plt.pause(0.01)  # Small pause to update the plot

# if __name__ == '__main__':
#     rospy.init_node('pose_and_plan_plotter')

#     # Subscribe to amcl_pose and global plan topics
#     rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, amcl_pose_callback)
#     #rospy.Subscriber('/move_base/TrajectoryPlannerROS/global_plan', Path, global_plan_callback)
#     rospy.Subscriber('/move_base/DWAPlannerROS/global_plan', Path, global_plan_callback)
    
#     # Start plotting thread
#     plotter = Thread(target=plot_thread)
#     plotter.start()

#     rospy.spin()

#     # Ensure the plot thread terminates cleanly
#     plotter.join()





# import rospy
# from geometry_msgs.msg import PoseWithCovarianceStamped
# from nav_msgs.msg import Path
# import matplotlib.pyplot as plt
# from threading import Thread
# from queue import Queue

# # Queues to store data from ROS topics
# pose_data = Queue()
# path_data = Queue()

# def amcl_pose_callback(msg):
#     # Extract position from amcl_pose message and store it in the queue
#     x = msg.pose.pose.position.x
#     y = msg.pose.pose.position.y
#     pose_data.put((x, y))

# def global_plan_callback(msg):
#     # Extract the global plan path and store it in the queue
#     path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]
#     path_data.put(path)

# def plot_thread():
#     # Initialize the plot
#     plt.ion()
#     fig, ax = plt.subplots()
#     pose_x_data, pose_y_data = [], []
#     path_x_data, path_y_data = [], []
#     path_fixed = False  # To track if the global plan has been fixed

#     while not rospy.is_shutdown():
#         # Update pose data
#         while not pose_data.empty():
#             x, y = pose_data.get()
#             pose_x_data.append(x)
#             pose_y_data.append(y)

#         # Update path data only once to fix the global plan
#         if not path_fixed:
#             while not path_data.empty():
#                 path = path_data.get()
#                 path_x_data, path_y_data = zip(*path)
#                 path_fixed = True  # Mark the global plan as fixed

#         # Plotting
#         ax.clear()
#         ax.plot(pose_x_data, pose_y_data, label="Robot Position", color="blue")
#         if path_fixed:
#             ax.plot(path_x_data, path_y_data, label="Global Plan", color="red")
#         ax.set_xlim([0, 5])  # Adjust these values as needed to make the plot larger
#         ax.set_ylim([0, 5])  # Adjust these values as needed to make the plot larger

#         ax.set_xlabel('X Position')
#         ax.set_ylabel('Y Position')
#         ax.legend()
#         plt.draw()
#         plt.pause(0.01)  # Small pause to update the plot

# if __name__ == '__main__':
#     rospy.init_node('pose_and_plan_plotter')

#     # Subscribe to amcl_pose and global plan topics
#     rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, amcl_pose_callback)
#     rospy.Subscriber('/move_base/NavfnROS/plan', Path, global_plan_callback)
    
#     # Start plotting thread
#     plotter = Thread(target=plot_thread)
#     plotter.start()

#     rospy.spin()

#     # Ensure the plot thread terminates cleanly
#     plotter.join()

# import rospy
# from geometry_msgs.msg import PoseWithCovarianceStamped
# from nav_msgs.msg import Path
# import matplotlib.pyplot as plt
# from threading import Thread
# from queue import Queue
# import csv

# # Queues to store data from ROS topics
# pose_data = Queue()
# path_data = Queue()

# # CSV file to store the data
# csv_file = open('robot_and_plan_data.csv', mode='w', newline='')
# csv_writer = csv.writer(csv_file)
# csv_writer.writerow(['Timestamp', 'Pose_X', 'Pose_Y', 'Plan_X', 'Plan_Y'])  # Header

# def amcl_pose_callback(msg):
#     # Extract position from amcl_pose message and store it in the queue
#     x = msg.pose.pose.position.x
#     y = msg.pose.pose.position.y
#     timestamp = msg.header.stamp.to_sec()
#     pose_data.put((timestamp, x, y))

# def global_plan_callback(msg):
#     # Extract the global plan path and store it in the queue
#     path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]
#     path_data.put(path)

# def plot_thread():
#     # Initialize the plot
#     plt.ion()
#     fig, ax = plt.subplots()
#     pose_x_data, pose_y_data = [], []
#     path_x_data, path_y_data = [], []

#     while not rospy.is_shutdown():
#         # Update pose data
#         while not pose_data.empty():
#             timestamp, x, y = pose_data.get()
#             pose_x_data.append(x)
#             pose_y_data.append(y)

#             # Write robot position to CSV
#             if path_x_data and path_y_data:
#                 for px, py in zip(path_x_data, path_y_data):
#                     csv_writer.writerow([timestamp, x, y, px, py])
#             else:
#                 csv_writer.writerow([timestamp, x, y, '', ''])

#         # Update path data by accumulating new points
#         while not path_data.empty():
#             path = path_data.get()
#             path_x_data = [p[0] for p in path]
#             path_y_data = [p[1] for p in path]

#         # Plotting
#         ax.clear()
#         ax.plot(pose_x_data, pose_y_data, label="Robot Position", color="blue")
#         if path_x_data and path_y_data:
#             ax.plot(path_x_data, path_y_data, label="Global Plan", color="red")
#         ax.set_xlim([min(pose_x_data + path_x_data, default=0) - 1, max(pose_x_data + path_x_data, default=5) + 1])
#         ax.set_ylim([min(pose_y_data + path_y_data, default=0) - 1, max(pose_y_data + path_y_data, default=5) + 1])

#         ax.set_xlabel('X Position')
#         ax.set_ylabel('Y Position')
#         ax.legend()
#         plt.draw()
#         plt.pause(0.01)  # Small pause to update the plot

# if __name__ == '__main__':
#     rospy.init_node('pose_and_plan_plotter')

#     # Subscribe to amcl_pose and global plan topics
#     rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, amcl_pose_callback)
#     rospy.Subscriber('/move_base/NavfnROS/plan', Path, global_plan_callback)
    
#     # Start plotting thread
#     plotter = Thread(target=plot_thread)
#     plotter.start()

#     rospy.spin()

#     # Ensure the plot thread terminates cleanly
#     plotter.join()
#     csv_file.close()  # Close the CSV file after the program is terminated


# import rospy
# from geometry_msgs.msg import PoseWithCovarianceStamped
# from nav_msgs.msg import Path
# import matplotlib.pyplot as plt
# from threading import Thread
# from queue import Queue
# import numpy as np
# from scipy.interpolate import splev, splprep

# # Queues to store data from ROS topics
# pose_data = Queue()
# path_data = Queue()

# def amcl_pose_callback(msg):
#     # Extract position from amcl_pose message and store it in the queue
#     x = msg.pose.pose.position.x
#     y = msg.pose.pose.position.y
#     pose_data.put((x, y))

# def global_plan_callback(msg):
#     # Extract the global plan path and store it in the queue
#     path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]
#     path_data.put(path)

# def plot_thread():
#     # Initialize the plot
#     plt.ion()
#     fig, ax = plt.subplots()
#     pose_x_data, pose_y_data = [], []
#     plan_x_data, plan_y_data = [], []
#     passed_plan_x_data, passed_plan_y_data = [], []

#     # Open a file to save the passed plan
#     with open('passed_plan.txt', 'w') as f:
#         while not rospy.is_shutdown():
#             # Update pose data
#             while not pose_data.empty():
#                 x, y = pose_data.get()
#                 pose_x_data.append(x)
#                 pose_y_data.append(y)

#             # Update path data
#             while not path_data.empty():
#                 path = path_data.get()
#                 plan_x_data = [pose[0] for pose in path]
#                 plan_y_data = [pose[1] for pose in path]

#             # Tìm các điểm đã đi qua trong global plan
#             passed_plan_x_data = []
#             passed_plan_y_data = []
#             for i in range(len(plan_x_data)):
#                 for x, y in zip(pose_x_data, pose_y_data):
#                     if (x - plan_x_data[i])**2 + (y - plan_y_data[i])**2 < 0.1:
#                         passed_plan_x_data.append(plan_x_data[i])
#                         passed_plan_y_data.append(plan_y_data[i])
#                         break

#             # Nội suy đường passed plan bằng phương pháp spline
#             if len(passed_plan_x_data) > 2:
#                 tck, u = splprep([passed_plan_x_data, passed_plan_y_data], s=0)
#                 unew = np.arange(0, 1.01, 0.01)
#                 out = splev(unew, tck)
#                 passed_plan_x_data_spline = out[0]
#                 passed_plan_y_data_spline = out[1]
#             else:
#                 passed_plan_x_data_spline = passed_plan_x_data
#                 passed_plan_y_data_spline = passed_plan_y_data

#             # Save the passed plan to the file
#             for x, y in zip(passed_plan_x_data_spline, passed_plan_y_data_spline):
#                 f.write(f"{x:.4f} {y:.4f}\n")

#             # Plotting
#             ax.clear()
#             ax.plot(pose_x_data, pose_y_data, label="Robot Position", color="blue", linewidth=3)
#             ax.plot(plan_x_data, plan_y_data, label="Global Plan", color="white")
#             ax.plot(passed_plan_x_data_spline, passed_plan_y_data_spline, label="Passed Plan", color="red", linewidth=0.2)

#             ax.set_xlabel('X Position')
#             ax.set_ylabel('Y Position')
#             ax.legend()
#             plt.draw()
#             plt.pause(0.01)  # Small pause to update the plot

# if __name__ == '__main__':
#     rospy.init_node('pose_and_plan_plotter')

#     # Subscribe to amcl_pose and global plan topics
#     rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, amcl_pose_callback)
#     rospy.Subscriber('/move_base/NavfnROS/plan', Path, global_plan_callback)
    
#     # Start plotting thread
#     plotter = Thread(target=plot_thread)
#     plotter.start()

#     rospy.spin()

#     # Ensure the plot thread terminates cleanly
#     plotter.join()

# import rospy
# from geometry_msgs.msg import PoseWithCovarianceStamped
# from nav_msgs.msg import Path
# import matplotlib.pyplot as plt
# from threading import Thread
# from queue import Queue
# import numpy as np
# from scipy.interpolate import splev, splprep

# # Queues to store data from ROS topics
# pose_data = Queue()
# path_data = Queue()

# def amcl_pose_callback(msg):
#     # Extract position from amcl_pose message and store it in the queue
#     x = msg.pose.pose.position.x
#     y = msg.pose.pose.position.y
#     pose_data.put((x, y))

# def global_plan_callback(msg):
#     # Extract the global plan path and store it in the queue
#     path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]
#     path_data.put(path)

# def plot_thread():
#     # Initialize the plot
#     plt.ion()
#     fig, ax = plt.subplots()
#     pose_x_data, pose_y_data = [], []
#     plan_x_data, plan_y_data = [], []
#     passed_plan_x_data, passed_plan_y_data = [], []

#     # Open a file to save the passed plan
#     with open('passed_plan.txt', 'w') as f:
#         while not rospy.is_shutdown():
#             # Update pose data
#             while not pose_data.empty():
#                 x, y = pose_data.get()
#                 pose_x_data.append(x)
#                 pose_y_data.append(y)

#             # Update path data
#             while not path_data.empty():
#                 path = path_data.get()
#                 plan_x_data = [pose[0] for pose in path]
#                 plan_y_data = [pose[1] for pose in path]

#             # Tìm các điểm đã đi qua trong global plan
#             passed_plan_x_data = []
#             passed_plan_y_data = []
#             for i in range(len(plan_x_data)):
#                 for x, y in zip(pose_x_data, pose_y_data):
#                     if (x - plan_x_data[i])**2 + (y - plan_y_data[i])**2 < 0.1:
#                         passed_plan_x_data.append(plan_x_data[i])
#                         passed_plan_y_data.append(plan_y_data[i])
#                         break

#             # Nội suy đường passed plan bằng phương pháp spline
#             if len(passed_plan_x_data) > 2:
#                 tck, u = splprep([passed_plan_x_data, passed_plan_y_data], s=0)
#                 unew = np.arange(0, 1.01, 0.01)
#                 out = splev(unew, tck)
#                 passed_plan_x_data_spline = out[0]
#                 passed_plan_y_data_spline = out[1]
#             else:
#                 passed_plan_x_data_spline = passed_plan_x_data
#                 passed_plan_y_data_spline = passed_plan_y_data

#             # Save the passed plan to the file
#             for x, y in zip(passed_plan_x_data_spline, passed_plan_y_data_spline):
#                 f.write(f"{x:.4f} {y:.4f}\n")

#             # Plotting
#             ax.clear()
#             ax.plot(pose_x_data, pose_y_data, label="Robot Position", color="blue", linewidth=3)
#             ax.plot(plan_x_data, plan_y_data, label="Global Plan", color="white")
#             ax.plot(passed_plan_x_data_spline, passed_plan_y_data_spline, label="Passed Plan", color="red", linewidth=0.2)

#             ax.set_xlabel('X Position')
#             ax.set_ylabel('Y Position')
#             ax.legend()
#             plt.draw()
#             plt.pause(0.01)  # Small pause to update the plot

#             # Lưu đường passed plan mịn lại vào file
#             np.savetxt('passed_plan_smooth.txt', np.column_stack((passed_plan_x_data_spline, passed_plan_y_data_spline)), fmt='%.4f')

# if __name__ == '__main__':
#     rospy.init_node('pose_and_plan_plotter')

#     # Subscribe to amcl_pose and global plan topics
#     rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, amcl_pose_callback)
#     rospy.Subscriber('/move_base/NavfnROS/plan', Path, global_plan_callback)
    
#     # Start plotting thread
#     plotter = Thread(target=plot_thread)
#     plotter.start()

#     rospy.spin()

#     # Ensure the plot thread terminates cleanly
#     plotter.join()



# import rospy
# from geometry_msgs.msg import PoseWithCovarianceStamped
# from nav_msgs.msg import Path
# import matplotlib.pyplot as plt
# from threading import Thread
# from queue import Queue
# import numpy as np
# from scipy.interpolate import splev, splprep

# # Queues to store data from ROS topics
# pose_data = Queue()
# path_data = Queue()

# def amcl_pose_callback(msg):
#     # Extract position from amcl_pose message and store it in the queue
#     x = msg.pose.pose.position.x
#     y = msg.pose.pose.position.y
#     pose_data.put((x, y))

# def global_plan_callback(msg):
#     # Extract the global plan path and store it in the queue
#     path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]
#     path_data.put(path)

# def plot_thread():
#     # Initialize the plot
#     plt.ion()
#     fig, ax = plt.subplots()
#     pose_x_data, pose_y_data = [], []
#     plan_x_data, plan_y_data = [], []
#     passed_plan_x_data, passed_plan_y_data = [], []
#     passed_points = []

#     # Open a file to save the passed plan
#     with open('passed_plan.txt', 'w') as f:
#         while not rospy.is_shutdown():
#             # Update pose data
#             while not pose_data.empty():
#                 x, y = pose_data.get()
#                 pose_x_data.append(x)
#                 pose_y_data.append(y)

#             # Update path data
#             while not path_data.empty():
#                 path = path_data.get()
#                 plan_x_data = [pose[0] for pose in path]
#                 plan_y_data = [pose[1] for pose in path]

#             # Tìm các điểm đã đi qua trong global plan
#             for i in range(len(plan_x_data)):
#                 for x, y in zip(pose_x_data, pose_y_data):
#                     if (x - plan_x_data[i])**2 + (y - plan_y_data[i])**2 < 0.1 and (plan_x_data[i], plan_y_data[i]) not in passed_points:
#                         passed_points.append((plan_x_data[i], plan_y_data[i]))
#                         passed_plan_x_data.append(plan_x_data[i])
#                         passed_plan_y_data.append(plan_y_data[i])
#                         break

#             # Nội suy đường passed plan bằng phương pháp spline
#             if len(passed_plan_x_data) > 2:
#                 tck, u = splprep([passed_plan_x_data, passed_plan_y_data], s=0)
#                 unew = np.arange(0, 1.01, 0.01)
#                 out = splev(unew, tck)
#                 passed_plan_x_data_spline = out[0]
#                 passed_plan_y_data_spline = out[1]
#             else:
#                 passed_plan_x_data_spline = passed_plan_x_data
#                 passed_plan_y_data_spline = passed_plan_y_data

#             # Save the passed plan to the file
#             for x, y in zip(passed_plan_x_data_spline, passed_plan_y_data_spline):
#                 f.write(f"{x:.4f} {y:.4f}\n")

#             # Plotting
#             ax.clear()
#             ax.plot(pose_x_data, pose_y_data, label="Robot Position", color="blue", linewidth=3)
#             ax.plot(plan_x_data, plan_y_data, label="Global Plan", color="white")
#             ax.plot(passed_plan_x_data_spline, passed_plan_y_data_spline, label="Passed Plan", color="red", linewidth=0.3)
           


#             ax.set_xlabel('X Position')
#             ax.set_ylabel('Y Position')
#             ax.legend()
#             plt.draw()
#             plt.pause(0.01)  # Small pause to update the plot

#             # Lưu đường passed plan mịn lại vào file
#             np.savetxt('passed_plan_smooth.txt', np.column_stack((passed_plan_x_data_spline, passed_plan_y_data_spline)), fmt='%.4f')

# if __name__ == '__main__':
#     rospy.init_node('pose_and_plan_plotter')

#     # Subscribe to amcl_pose and global plan topics
#     rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, amcl_pose_callback)
#     rospy.Subscriber('/move_base/NavfnROS/plan', Path, global_plan_callback)
    
#     # Start plotting thread
#     plotter = Thread(target=plot_thread)
#     plotter.start()

#     rospy.spin()

#     # Ensure the plot thread terminates cleanly
#     plotter.join()

import rospy
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav_msgs.msg import Path
import matplotlib.pyplot as plt
from threading import Thread
from queue import Queue
import numpy as np
from scipy.interpolate import splev, splprep

# Queues to store data from ROS topics
pose_data = Queue()
path_data = Queue()

def amcl_pose_callback(msg):
    # Extract position from amcl_pose message and store it in the queue
    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y
    pose_data.put((x, y))

def global_plan_callback(msg):
    # Extract the global plan path and store it in the queue
    path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]
    path_data.put(path)

def plot_thread():
    # Initialize the plot
    plt.ion()
    fig, ax = plt.subplots()
    pose_x_data, pose_y_data = [], []
    passed_plan_x_data, passed_plan_y_data = [], []
    passed_points = []

    # Open a file to save the passed plan
    with open('passed_plan.txt', 'w') as f:
        while not rospy.is_shutdown():
            # Update pose data
            while not pose_data.empty():
                x, y = pose_data.get()
                pose_x_data.append(x)
                pose_y_data.append(y)

            # Update path data
            while not path_data.empty():
                path = path_data.get()
                for i in range(len(path)):
                    x, y = path[i]
                    if (x - pose_x_data[-1])**2 + (y - pose_y_data[-1])**2 < 0.1 and (x, y) not in passed_points:
                        passed_points.append((x, y))
                        passed_plan_x_data.append(x)
                        passed_plan_y_data.append(y)
                        break

            # Nội suy đường passed plan bằng phương pháp spline
            if len(passed_plan_x_data) > 2:
                passed_plan_x_data_spline, passed_plan_y_data_spline = [], []
                tck, u = splprep([passed_plan_x_data, passed_plan_y_data], s=0)
                unew = np.arange(0, 1.01, 0.01)
                out = splev(unew, tck)
                passed_plan_x_data_spline = out[0]
                passed_plan_y_data_spline = out[1]
            else:
                passed_plan_x_data_spline = passed_plan_x_data
                passed_plan_y_data_spline = passed_plan_y_data

            # Save the passed plan to the file
            for x, y in zip(passed_plan_x_data_spline, passed_plan_y_data_spline):
                f.write(f"{x:.4f} {y:.4f}\n")

            # Plotting
            ax.clear()
            ax.plot(pose_x_data, pose_y_data, label="Robot Position", color="blue", linewidth=1) #2
            # ax.scatter([point[0] for point in passed_points], [point[1] for point in passed_points], label="Passed Points", color="green", s=5)
            ax.plot(passed_plan_x_data_spline, passed_plan_y_data_spline, label="Path Planning", color="red", linewidth=1)#2.5
            ax.set_xlim([-5, 5])
            ax.set_ylim([-5, 5])
            ax.set_xlabel('X Position')
            ax.set_ylabel('Y Position')
            ax.legend()
            plt.draw()
            plt.pause(0.01)  # Small pause to update the plot

            # Lưu đường passed plan mịn lại vào file
            np.savetxt('passed_plan_smooth.txt', np.column_stack((passed_plan_x_data_spline, passed_plan_y_data_spline)), fmt='%.4f')

if __name__ == '__main__':
    rospy.init_node('pose_and_plan_plotter')

    # Subscribe to amcl_pose and global plan topics
    rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, amcl_pose_callback)
    rospy.Subscriber('/move_base/NavfnROS/plan', Path, global_plan_callback)
    # rospy.Subscriber('/move_base/TrajectoryPlannerROS/global_plan', Path, global_plan_callback)
    # Start plotting thread
    plotter = Thread(target=plot_thread)
    plotter.start()

    rospy.spin()

    # Ensure the plot thread terminates cleanly
    plotter.join()