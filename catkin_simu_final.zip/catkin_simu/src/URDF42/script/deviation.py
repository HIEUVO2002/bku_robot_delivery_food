import rospy
from geometry_msgs.msg import PoseWithCovarianceStamped
from nav_msgs.msg import Path
import matplotlib.pyplot as plt
from threading import Thread
from queue import Queue
import numpy as np

# Queues to store data from ROS topics
pose_data = Queue()
path_data = Queue()

def amcl_pose_callback(msg):
    # Extract position from amcl_pose message and store it in the queue
    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y
    pose_data.put((x, y))

def path_callback(msg):
    # Extract the plan path and store it in the queue
    path = [(pose.pose.position.x, pose.pose.position.y) for pose in msg.poses]
    path_data.put(path)

def compute_error(pose_point, path):
    # Find the closest point on the planned path to the pose_point
    path_array = np.array(path)
    distances = np.sqrt((path_array[:, 0] - pose_point[0])**2 + (path_array[:, 1] - pose_point[1])**2)
    min_distance = np.min(distances)
    return min_distance

def plot_thread():
    # Initialize the plot
    plt.ion()
    fig, ax = plt.subplots()
    pose_x_data = []
    pose_y_data = []
    error_data = []
    time_data = []
    path = []

    start_time = rospy.get_time()

    while not rospy.is_shutdown():
        current_time = rospy.get_time() - start_time

        # Update pose data
        while not pose_data.empty():
            x, y = pose_data.get()
            pose_x_data.append(x)
            pose_y_data.append(y)

            # Compute error if path is available
            if path:
                error = compute_error((x, y), path)
                error_data.append(error/10)
                time_data.append(current_time)

        # Update path data
        if not path_data.empty():
            path = path_data.get()

        # Plotting
        ax.clear()
        if error_data:
            ax.plot(time_data, error_data, label="Error (Pose vs Plan)", color="purple")
        ax.set_xlabel('Time (s)')
        ax.set_ylabel('Error (m)')
        ax.legend()
        plt.draw()
        plt.pause(0.01)  # Small pause to update the plot

if __name__ == '__main__':
    rospy.init_node('pose_and_path_error_plotter')

    # Subscribe to amcl_pose and global plan topics
    rospy.Subscriber('/amcl_pose', PoseWithCovarianceStamped, amcl_pose_callback)
    rospy.Subscriber('/move_base/TrajectoryPlannerROS/global_plan', Path, path_callback)
    # rospy.Subscriber('/move_base/DWAPlannerROS/global_plan', Path, path_callback)
    
    # Start plotting thread
    plotter = Thread(target=plot_thread)
    plotter.start()

    rospy.spin()

    # Ensure the plot thread terminates cleanly
    plotter.join()
