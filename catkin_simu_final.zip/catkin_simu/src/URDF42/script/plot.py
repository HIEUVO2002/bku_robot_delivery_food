import matplotlib.pyplot as plt

# Đọc dữ liệu từ file txt
with open('passed_plan.txt', 'r') as f:
    lines = f.readlines()

x = []
y = []
for line in lines:
    values = line.strip().split()
    x.append(float(values[0]))
    y.append(float(values[1]))

# Tạo đồ thị
plt.figure(figsize=(8, 6))
plt.scatter(x, y, marker='o')

# Thêm tiêu đề và nhãn
plt.title('Đồ thị các điểm')
plt.xlabel('X')
plt.ylabel('Y')

# Hiển thị đồ thị
plt.show()