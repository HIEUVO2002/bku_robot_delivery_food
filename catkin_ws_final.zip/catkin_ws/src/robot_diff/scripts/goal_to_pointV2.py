#!/usr/bin/env python3


import rospy
import roslib
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist
from geometry_msgs.msg import Pose2D
from math import pow, atan2, sqrt
from math import radians, degrees
import sys
import tf
import math

class ControlBot:

    def __init__(self):
        # We create the node and make it unique "True"
        rospy.init_node('Robot_controller', anonymous=True)

        #Post speed
        self.velocity_publisher = rospy.Publisher('/cmd_vel',
                                                  Twist, queue_size=10)

        # Subscribe to odometry
        self.pose_subscriber = rospy.Subscriber('/odom',
                                                Odometry, self.update_pose)

        self.pose = Pose2D()
        self.rate = rospy.Rate(10)
        self.location_met = True
        self.angle_met = True
        self.constant_vel = 0.1
        self.constant_angular = 0.1

    def update_pose(self, data):
        """When the subscriber receives a new message, the position is updated."""
        
        position = data.pose.pose.position        
        orientation = data.pose.pose.orientation
        roll, pitch, yaw = tf.transformations.euler_from_quaternion(
            [orientation.x, orientation.y, orientation.z, orientation.w])
        self.pose.x = round(position.x, 4)
        self.pose.y = round(position.y, 4)
        self.pose.theta = yaw

    def euclidean_distance(self, goal_pose):
        """Euclidean distance between the current position and the goal."""
        return sqrt(pow((goal_pose.x - self.pose.x), 2) +
                    pow((goal_pose.y - self.pose.y), 2))

    def steering_angle(self, goal_pose):
        """Angle direction."""
        return atan2(goal_pose.y - self.pose.y, goal_pose.x - self.pose.x)

    def linear_vel(self, goal_pose):
        return self.euclidean_distance(goal_pose)

    #constant : resolution
    def angular_vel(self, goal_pose):
        goal_angle = self.steering_angle(goal_pose)
        current_angle = math.fmod(self.pose.theta, 2*math.pi)
        return  (math.fmod((goal_angle - current_angle + math.pi),(2 * math.pi)) - math.pi)

    def move2goal(self):
        """Move towards the target"""
        goal_pose = Pose2D()

        # Get the input from the user.
        point_x, point_y = input("Enter the coordinates separated by comma (x,y): ").split(",")
        goal_pose.x = float(point_x)
        goal_pose.y = float(point_y)

        # check this tolerance, it depends on control speed
        distance_tolerance = 0.15
        angular_tolerance  = 0.15
        
        
        vel_msg = Twist()
        
      

        while not rospy.is_shutdown() and self.euclidean_distance(goal_pose) >= distance_tolerance:

              angular_error = self.angular_vel(goal_pose)
              if angular_error >= angular_tolerance :
                    self.angle_met = False  
              else :
                    self.angle_met = True
              if self.angle_met == False:
                  velocidad_linear = 0
                  velocidad_angular = self.constant_angular*self.angular_vel(goal_pose)
              else :
                  velocidad_linear = self.linear_vel(goal_pose)*self.constant_vel
                  velocidad_angular = 0

              

            #   velocidad_linear = self.linear_vel(goal_pose)
              
            #   velocidad_angular = self.angular_vel(goal_pose)
              
       

              print("v_linear: ",velocidad_linear)
              print("v_angular: ",velocidad_angular)                 
              print("pose actual x: ",self.pose.x)
              print("pose actual y: ",self.pose.y)
              print("angular actual:",self.pose.theta)
              print("pose objetive x: ",goal_pose.x)
              print("pose objetive y: ",goal_pose.y)
              print("angular objetive:",self.steering_angle(goal_pose))
              print("euclidean_distance:",self.euclidean_distance(goal_pose))
              print("--------------------------------------------------------")                 
                      

		# Linear velocity in the x-axis.
              vel_msg.linear.x = velocidad_linear
              vel_msg.linear.y = 0
              vel_msg.linear.z = 0

		# Angular velocity in the z-axis.
              vel_msg.angular.x = 0
              vel_msg.angular.y = 0
              vel_msg.angular.z = velocidad_angular

		# Publishing our vel_msg
              self.velocity_publisher.publish(vel_msg)

		# Publish at the desired rate.
              self.rate.sleep()


        # Stopping our robot after the movement is over.
        vel_msg.linear.x = 0
        vel_msg.angular.z = 0
        self.velocity_publisher.publish(vel_msg)
        
        answer = input("Do you want to enter another point? y/n:  ")
        if answer == "y":
            self.move2goal()
        else:
            rospy.signal_shutdown("Program completed")
            sys.exit()

        # If we press control + C, the node will stop.
        rospy.spin()

if __name__ == '__main__':
    try:
        x = ControlBot()    
        rospy.loginfo("Start the node")      
        x.move2goal()
    except KeyboardInterrupt:
        print("Shutting down")      